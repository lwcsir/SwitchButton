package com.example.mayn.myfisrtapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.mayn.myfisrtapp.util.FileAES;

public class MainActivity extends AppCompatActivity {

    private String mUserId = "37fa31e2-9d1d-4919-a74b-e9c58db02907";

    //加密的字符
    private String mData = "dfHWrnDNAqLg4Z/1+HJp0WloNSCCMza4GpsNgu6wBrTx/HpwrLABGRqwWw7o1tHljtvPfiMCho9hx6R/JozmCvp7Wg3E79q8BAAJOCQJCUoSCPld9+DjCva5qcwdKhoNDJyMtcEe8gX7OHuD30uQ/f2CX/VMKpn9N7yfE6DV4BfYPefce+V6SpZXEy5YqnFIyDVPEcNCXWIR3cdTAXc1V1i6VjDg+t6DkCWOEi6NU5PueCPzi1EnIl66SJOahZK2kkhND3Qm8Or8Ylyd5YRVQTkLAY66+5wdb5fZavEFc17fxI3ocMDWJ1Jkj7zMrZnyFpNeQBgSFLSDH+NRRyZmWw==";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // //这里是要处理h5传过来的 加密参数。37fa31e2-9d1d-4919-a74b-e9c58db02907
        String key = FileAES.getMiKey(mUserId); //前端生成key
        Log.e("FileAES", key + "");
        //将加密字符和key放入此方法中
        //               String str = FileAES.decrypt("0vMRBHN/c8+Bo+dPgP3dwSGDc/bens6opLWHhXVPv24AfNLUGDFnyzaOrHejGQmKeJhoPPOMs99fD3d9re48T+dhqxPhyAITbnz5zXsgXuulQevVzTnoA4Ur+JehvK84OlI1mhVJ8UisiJt3BFfBjZe0+e09D9ScMZaNkT1eYDHOUjgY76a55uH4/n/PNdvBixAQnS+OVhZ3s+54cbOXW4R1bz5va/XZnN0MQYXvoAGhL5plcaj7kwPvytg0BLecQbv7tXecf8YF1btjm5fZxd54bvLt3LQv40bTHOY4ppYKrLD2Bjidbse4Ym3T4k7BnY/I8i/0lvfQNSZsB49CyA==",key);
        String str = FileAES.decrypt(mData +
                "", key);
        Log.e("FileAES", str + "");
    }
}
